<?php
session_start();
if(!isset($_SESSION["usuario"])){
        echo ' 
        <script>
                alert("Inicia sesion, por favor");
                window.location="index.php";
        </script>
        ';
        session_destroy();
        die();

}

?>


<!DOCTYPE html>
<html lang  ="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CALCULA TU CREDITO AQUI</title>
        <link rel="stylesheet" href="assets/css/estilos2.css">   
</head>
<?php

$mensaje = "BIENVENIDO, CALCULA TU CRÉDITO VEHICULAR AQUÍ";

echo "<h1 style='text-align: center; padding: 20px; background-color: #4CAF50; color: white;'>$mensaje</h1>";

?>
</html>
<!DOCTYPE html>
<html lang="es">
<body> 
        <h1> BOTÓN PARA CERRAR SESIÓN </h1>
        <a href="php/cerrar_sesion.php">Cerrar Sesion</a>

</body>

<body> 
    <main>  
            <div class="contenedor__bienvenido">
    
                <div class="contenedor__formulario_datos"> 
                    <form action="php/registro_datos_be.php" method= "POST"  class="formulario__datos">
                        <h2>  CALCULAR AQUÍ</h2>
                        <input type="text" placeholder="Tipo Moneda" name = "tipo_moneda" > 
                        <input type="text" placeholder="Prestamo" name = "prestamo" > 
                        <input type="text" placeholder="Cuota Inicial" name = "cuota_inicial" > 
                        <input type="text" placeholder="Fecha Prestamo" name = "fecha_prestamo" > 
                        <input type="text" placeholder="Tipo tasa" name = "tipo_tasa" > 
                        <input type="text" placeholder="Tasa anual" name = "tasa_anual" > 
                        <input type="text" placeholder="periodo Gracia" name = "periodo_gracia" > 
                        <input type="text" placeholder="Seguro Desgravamen" name = "seguro_desgravamen" > 
                        <input type="text" placeholder="Seguro Vehicular" name = "seguro_vehicular" > 
                        <input type="text" placeholder="Portes" name = "portes" > 
                        <button>Calcular</button>      
                    </form>  

                </div>

            </div>
    </main>
    <script src="assets/js/script.js"></script>
</body>

</html>