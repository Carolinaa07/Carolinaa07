

<?php
    
    include 'conexion_be.php';

    $tipo_moneda = $_POST['tipo_moneda'];
    $prestamo = $_POST['prestamo'];
    $cuota_inicial = $_POST['cuota_inicial'];
    $fecha_prestamo = $_POST['fecha_prestamo'];
    $tipo_tasa = $_POST['tipo_tasa'];
    $tasa_anual = $_POST['tasa_anual'];
    $periodo_gracia = $_POST['periodo_gracia'];
    $seguro_desgravamen= $_POST['seguro_desgravamen'];
    $seguro_vehicular = $_POST['seguro_vehicular'];
    $portes = $_POST['portes'];


    $query = "INSERT INTO datos(tipo_moneda, prestamo, cuota_inicial, fecha_prestamo,tipo_tasa,tasa_anual,periodo_gracia,seguro_desgravamen,seguro_vehicular,portes) 
    VALUES('$tipo_moneda','$prestamo','$cuota_inicial','$fecha_prestamo','$tipo_tasa','$tasa_anual','$periodo_gracia','$seguro_desgravamen','$seguro_vehicular','$portes')";


    $ejecutar = mysqli_query($conexion,$query);
    if ($ejecutar){
        echo  '
        <script>
        alert ("Datos registrados correctamente");
        window.location="../resultados.php";
        </script>
        ';
        ;
    }else{
        echo '
        <script>
            alert ("Intentelo de nuevo, No Datos");
            window.location="../index.php";
        </script>
        ';
    }  

    
    mysqli_close($conexion);
?>      

