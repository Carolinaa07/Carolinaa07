
const moneda = document.getElementById('moneda');
const prestamo = document.getElementById('prestamo');
const cuotainicial = document.getElementById('cuotainicial');
const fechaprestamo = document.getElementById('fechaprestamo');
const tipotasa = document.querySelector('tipotasa');
const tasaanual = document.getElementById('tasaanual');
const periodogracia = document.getElementById('periodogracia');
const segurode = document.getElementById('segurode');
const segurovehicular = document.getElementById('segurovehicular');
const portes = document.getElementById('portes');

const btnCalcular = document.getElementById('btnCalcular');
const llenarTabla = document.querySelector('#lista-tabla tbody');


btnCalcular.addEventListener('click', () => {
    calcularCuota(moneda.value, prestamo.value, cuotainicial.value, fechaprestamo.value, tipotasa.value, tasaanual.value
        , periodogracia.value, segurode.value, segurovehicular.value, portes.value);
})

function calcularCuota(moneda, prestamo, cuotainicial, fechaprestamo, tipotasa, tasaanual
    , periodogracia, segurode, segurovehicular, portes){

    while(llenarTabla.firstChild){
        llenarTabla.removeChild(llenarTabla.firstChild);
    }

    let fechas = [];
    let fechaActual = Date.now();
    let mes_actual = moment(fechaActual);
    mes_actual.add(1, 'month');    

    
}


