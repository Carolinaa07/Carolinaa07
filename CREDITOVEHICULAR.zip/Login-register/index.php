<?php
session_start();
if(isset($_SESSION['usuario'])){
    header  ("location:bienvenido.php");
}
?>
<!DOCTYPE html>
<html lang  ="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Y Registro - UPC  </title>
        <link rel="stylesheet" href="assets/css/estilos.css">   
</head>
<body> 
    <main>  
            <div class="contenedor__todo">
                <div class="caja__trasera">

                    <div class="caja__trasera-login">
                        <h3>¿Ya tienes cuenta en nuestra web?</h3>
                        <p>Inicia sesión e ingresa a la web.</p>
                        <button id="btn__iniciar-sesion">Iniciar sesion</button>
                    </div>

                    <div class="caja__trasera-register">
                        <h3>¿Aun no tienes cuenta? Registrate..</h3>
                        <h3>Encuentra las mejores ofertas vehiculares!</h3>
                        <p>Registrate para poder iniciar sesion.</p>
                        <button id="btn__registrarse">Registrarse</button>
                    </div>
                    
                </div>
                <div class="contenedor__login-register"> 
                <form action="php/login_usuario_be.php" method = "POST" class="formulario__login">
                        <h2>Iniciar sesion</h2>
                        <input type="text" placeholder="Correo Electronico"name="correo">   
                        <input type="password" placeholder="Contraseña"name="contrasena" > 
                        <button>Empezar</button>    
                    </form>  
                    <form action="php/registro_usuario_be.php" method= "POST"  class="formulario__register">
                        <h2>Registrarse</h2>
                        <input type="text" placeholder="Nombre Competo" name = "nombre_completo" > 
                        <input type="text" placeholder="Correo Electronico" name = "correo" > 
                        <input type="text" placeholder="Nombre de Usuario" name = "usuario" > 
                        <input type="password" placeholder="Contraseña" name = "contrasena" > 
                        <button>Registrarse</button>        
                    </form>  

                </div>

            </div>
    </main>
    <script src="assets/js/script.js"></script>
</body>
