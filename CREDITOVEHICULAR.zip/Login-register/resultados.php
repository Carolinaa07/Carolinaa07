<!DOCTYPE html>
<html lang  ="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="assets/css/estilos2.css">   
</head>
<?php

$mensaje = "USUARIO, ESTOS SON TUS RESULADOS";

echo "<h1 style='text-align: center; padding: 20px; background-color: #4CAF50; color: white;'>$mensaje</h1>";

?>
<body> 
        <h2> BOTÓN PARA CERRAR SESIÓN </h2>
        <a href="php/cerrar_sesion.php">Cerrar Sesion</a>

</body>
<!-- llamada a bootstrap -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<body>
    <div class="container">
        <div class="row mt-3">
            <div class="col-6">      
                <h2>DATOS DEL CREDITO</h2>
                <div class="form-group">
                    <label for="tasa_mensual">Tasa mensual</label>
                    <input type="text" class="form-control" id="tasa_mensual" placeholder="Tasa mensual aquí">
                </div>
                <div class="form-group">
                    <label for="prestamo">Prestamo</label>
                    <input type="text" class="form-control" id="prestamo" placeholder="Importe del prestamo aquí">
                </div>
                <div class="form-group">
                    <label for="cuota">Numero de cuotas</label>
                    <input type="text" class="form-control" id="cuota" placeholder="Numero de cuota aqui">
                </div>
                <div class="form-group">
                    <label for="cuota_simple">Cuota simple</label>
                    <input type="text" class="form-control" id="cuota_simple" placeholder="Cuota simple aqui">
                </div>
                <div class="form-group">
                    <label for="tcea">TCEA</label>
                    <input type="text" class="form-control" id="tcea" placeholder="TCEA">
                </div>
                <div class="form-group">
                    <label for="tir">TIR</label>
                    <input type="text" class="form-control" id="tir" placeholder="TIR">
                </div>
                <button type="submit" class="btn btn-primary" id="btnCalcular">DE ACUERDO</button>
            </div>
            <div class="col-6">
                <table id="lista-tabla" class="table">
                    <thead>
                        <tr>
                            <th>Tasa Mensual</th>
                            <th>Prestamo</th>
                            <th>Nro Cuotas</th>
                            <th>Cuota simple</th>
                            <th>TCEA</th>
                            <th>TIR</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>

    </div>
    <script src="js/calculo.js"></script>
    <script src="js/moment.js"></script>

    <?php
